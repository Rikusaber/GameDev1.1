Title: In Somnia

Created by: Carol Lu, Enoch Huang, Igor Carvalho, Kasalina Nabakooza, Kyle Ring, Richard Forng

soundtrack: A Strange Dream by Gunnar Johnsén

Contributions by Enoch: 
	- coded the Intro state
	- Coded the PlayState scene //how specific do we want to be about breaking down contributions to the playstate?
	- Putting all the individual scenes together and linking them into a cohesive game
	- coded in the animations of the player (transitioning from one animation to the other, including the in water animations)
	- coded the UI for PlayState and instructions for the minigames
	- Minor bug fixes and final edits for the gamme
	
Contributions by Kyle:
	- Implemented the background music for the game
	- Implemented the ability for the player to interact with game objects
	- Coded the second mini game (Mini2PlayState)
	
Contributions by Carol:
	- Coded both minigames 
	- Came up with the Intro text
	- came up with the concepts and themes behind minigames

Contributions by Kasalina: 
	- art assets
	- minigame 2 maze map using ogmo

Contributions by Richard:
	- art assets
	- player spritesheet
	
Contributions by Igor:
	- Logo
	- 

	
	